OK_FORMAT = True

test = {'name': 'stub', 'points': 0, 'suites': [{'cases': [{'code': '>>> print(1+2)\n3\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
