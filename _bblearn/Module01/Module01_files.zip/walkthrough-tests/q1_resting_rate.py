OK_FORMAT = True

test = {   'name': 'q1_resting_rate',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print('heart_rate_reserve is an integer:', isinstance(heart_rate_reserve, int))\nheart_rate_reserve is an integer: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('heart_rate_reserve is between 0 and 220:', (heart_rate_reserve < 220) & (heart_rate_reserve > 0))\n"
                                               'heart_rate_reserve is between 0 and 220: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('heart_rate_reserve =', heart_rate_reserve)\nheart_rate_reserve = 126\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
