OK_FORMAT = True

test = {   'name': 'q1_resting_rate',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(heart_rate_reserve, int)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (heart_rate_reserve < 220) & (heart_rate_reserve > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> heart_rate_reserve\n126', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
