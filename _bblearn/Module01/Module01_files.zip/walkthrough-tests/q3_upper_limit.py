OK_FORMAT = True

test = {   'name': 'q3_upper_limit',
    'points': 2,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(upper_target_zone, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> (upper_target_zone < 220) & (upper_target_zone > 0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> f'upper_target_zone = {upper_target_zone:0.1f}'\n'upper_target_zone = 167.1'", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
