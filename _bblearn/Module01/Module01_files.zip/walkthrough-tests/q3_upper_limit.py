OK_FORMAT = True

test = {   'name': 'q3_upper_limit',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print('upper_target_zone is a float:', isinstance(upper_target_zone, float))\nupper_target_zone is a float: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('upper_target_zone is between 0 and 220:', (upper_target_zone < 220) & (upper_target_zone > 0))\n"
                                               'upper_target_zone is between 0 and 220: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'upper_target_zone = {upper_target_zone:0.1f}')\nupper_target_zone = 167.1\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
