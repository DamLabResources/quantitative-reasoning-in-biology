OK_FORMAT = True

test = {   'name': 'q2_summary_vals',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q2_Actinobacteria_mean = {q2_Actinobacteria_mean:0.2f}')\nq2_Actinobacteria_mean = 95.42\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2_Bacteroidetes_mean = {q2_Bacteroidetes_mean:0.2f}')\nq2_Bacteroidetes_mean = 1.25\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2_Firmicutes_mean = {q2_Firmicutes_mean:0.2f}')\nq2_Firmicutes_mean = 5135.50\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2_Proteobacteria_mean = {q2_Proteobacteria_mean:0.2f}')\nq2_Proteobacteria_mean = 299.75\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
