OK_FORMAT = True

test = {   'name': 'q1_extract_single',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print(f'pat_3116 is an `DataFrame`: {isinstance(pat_3116, pd.DataFrame)}')\npat_3116 is an `DataFrame`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'len(pat_3116) = {len(pat_3116)}')\nlen(pat_3116) = 12\n", 'hidden': False, 'locked': False},
                                   {   'code': '>>> print(f"""pat_3116["Actinobacteria"].sum() = {pat_3116[\'Actinobacteria\'].sum()}""")\npat_3116["Actinobacteria"].sum() = 1145\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
