OK_FORMAT = True

test = {   'name': 'q3_mean_by_site',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q3_mean_phylum_site is a `DataFrame`: {isinstance(q3_mean_phylum_site, pd.DataFrame)}')\nq3_mean_phylum_site is a `DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q3_mean_phylum_site.index = {list(q3_mean_phylum_site.index)}')\n"
                                               "q3_mean_phylum_site.index = ['Ethmoid Culture (Deep to Ethmoid Bulla)', 'Ethmoid Tissue (Deep to Ethmoid Bulla)', 'Head of Inferior Turbinate Tissue', "
                                               "'Maxillary Sinus', 'Maxillary Sinus Tissue', 'Middle Meatus', 'Nasal Vestibule', 'Sphenoethmoidal Recess Tissue', 'Sphenoid', 'Sphenoid Tissue', "
                                               "'Superior Meatus', 'Uncinate Process Tissue']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q3_mean_phylum_site.columns = {list(q3_mean_phylum_site.columns)}')\n"
                                               "q3_mean_phylum_site.columns = ['Actinobacteria', 'Bacteroidetes', 'Firmicutes', 'Proteobacteria']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q3_mean_phylum_site.sum().sum() = {q3_mean_phylum_site.sum().sum():0.2f}')\nq3_mean_phylum_site.sum().sum() = 50505.71\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
