OK_FORMAT = True

test = {   'name': 'q4_servere',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q4_severe_means is a `DataFrame`: {isinstance(q4_severe_means, pd.DataFrame)}')\nq4_severe_means is a `DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q4_severe_means.index = {list(q4_severe_means.index)}')\nq4_severe_means.index = [False, True]\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print(f'q4_severe_means.columns = {list(q4_severe_means.columns)}')\n"
                                               "q4_severe_means.columns = ['Actinobacteria', 'Bacteroidetes', 'Firmicutes', 'Proteobacteria']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q4_severe_means.sum().sum() = {q4_severe_means.sum().sum():0.2f}')\nq4_severe_means.sum().sum() = 8544.57\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
