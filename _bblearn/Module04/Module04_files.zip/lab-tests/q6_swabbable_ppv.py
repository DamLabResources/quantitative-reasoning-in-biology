OK_FORMAT = True

test = {   'name': 'q6_swabbable_ppv',
    'points': 10,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q6_highest_region is a `str`: {isinstance(q6_highest_region, str)}')\nq6_highest_region is a `str`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q6_best_ppv is a float:', isinstance(q6_best_ppv, float))\nq6_best_ppv is a float: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q6_best_ppv is [0, 1]:', (q6_best_ppv>=0) & (q6_best_ppv<=1))\nq6_best_ppv is [0, 1]: True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
