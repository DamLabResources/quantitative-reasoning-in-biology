OK_FORMAT = True

test = {   'name': 'q4_swabable',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'swabbable_data is a `DataFrame`: {isinstance(swabbable_data, pd.DataFrame)}')\nswabbable_data is a `DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(f\'swabbable_data is probably correct:\', "swabbable_data[\'Patient\'].sum() ==", swabbable_data[\'Patient\'].sum())\n'
                                               "swabbable_data is probably correct: swabbable_data['Patient'].sum() == 189742\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(f\'swabbable_data is probably correct:\', "swabbable_data[\'Actinobacteria\'].sum() ==", swabbable_data[\'Actinobacteria\'].sum())\n'
                                               "swabbable_data is probably correct: swabbable_data['Actinobacteria'].sum() == 93075\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(f\'swabbable_data is probably correct:\', "swabbable_data[\'Firmicutes\'].sum() ==", swabbable_data[\'Firmicutes\'].sum())\n'
                                               "swabbable_data is probably correct: swabbable_data['Firmicutes'].sum() == 211694\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q4_fraction_swabbable is a float:', isinstance(q4_fraction_swabbable, float))\nq4_fraction_swabbable is a float: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q4_fraction_swabbable is [0, 1]:', (q4_fraction_swabbable>=0) & (q4_fraction_swabbable<=1))\nq4_fraction_swabbable is [0, 1]: True\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
