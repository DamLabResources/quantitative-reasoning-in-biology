OK_FORMAT = True

test = {   'name': 'q1_add_outcomes',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'merged_data is a `DataFrame`: {isinstance(merged_data, pd.DataFrame)}')\nmerged_data is a `DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'merged_data.columns = {list(merged_data.columns)}')\n"
                                               "merged_data.columns = ['Patient', 'Location', 'CollectionType', 'Actinobacteria', 'Bacteroidetes', 'Firmicutes', 'Proteobacteria', 'num_otu', "
                                               "'Predominant', 'PID', 'severe_disease', 'disease_type']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'(merged_data["disease_type"] == "persistent").sum() ==\', (merged_data[\'disease_type\'] == \'persistent\').sum())\n'
                                               '(merged_data["disease_type"] == "persistent").sum() == 55\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'(merged_data["disease_type"] == "typical").sum() ==\', (merged_data[\'disease_type\'] == \'typical\').sum())\n'
                                               '(merged_data["disease_type"] == "typical").sum() == 29\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'(merged_data["disease_type"] == "severe").sum() ==\', (merged_data[\'disease_type\'] == \'severe\').sum())\n'
                                               '(merged_data["disease_type"] == "severe").sum() == 24\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
