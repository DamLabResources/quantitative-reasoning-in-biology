OK_FORMAT = True

test = {   'name': 'q3_mean_pivot',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q3_pivot is a `DataFrame`: {isinstance(q3_pivot, pd.DataFrame)}')\nq3_pivot is a `DataFrame`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print(f'q3_pivot.index = {list(q3_pivot.index)}')\n"
                                               "q3_pivot.index = ['Ethmoid Culture (Deep to Ethmoid Bulla)', 'Ethmoid Tissue (Deep to Ethmoid Bulla)', 'Head of Inferior Turbinate Tissue', 'Maxillary "
                                               "Sinus', 'Maxillary Sinus Tissue', 'Middle Meatus', 'Nasal Vestibule', 'Sphenoethmoidal Recess Tissue', 'Sphenoid', 'Sphenoid Tissue', 'Superior "
                                               "Meatus', 'Uncinate Process Tissue']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q3_pivot.columns = {list(q3_pivot.columns)}')\nq3_pivot.columns = ['persistent', 'severe', 'typical', 'relative_abundance']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> val = q3_pivot[\'persistent\'].sum()\n>>> print(f"q3_pivot[\'persistent\'].sum() == {val:0.0f}")\nq3_pivot[\'persistent\'].sum() == 20132\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> val = q3_pivot[\'severe\'].sum()\n>>> print(f"q3_pivot[\'severe\'].sum() == {val:0.0f}")\nq3_pivot[\'severe\'].sum() == 12469\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> val = q3_pivot[\'typical\'].sum()\n>>> print(f"q3_pivot[\'typical\'].sum() == {val:0.0f}")\nq3_pivot[\'typical\'].sum() == 6362\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> val = q3_pivot['relative_abundance'].sum()\n"
                                               '>>> print(f"q3_pivot[\'relative_abundance\'].sum() == {val:0.0f}")\n'
                                               "q3_pivot['relative_abundance'].sum() == 6180\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q3_ans is a `str`: {isinstance(q3_ans, str)}')\nq3_ans is a `str`: True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
