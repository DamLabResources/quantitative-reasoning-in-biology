OK_FORMAT = True

test = {   'name': 'q2_count_pivot',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q2_pivot is a `DataFrame`: {isinstance(q2_pivot, pd.DataFrame)}')\nq2_pivot is a `DataFrame`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print(f'q2_pivot.index = {list(q2_pivot.index)}')\n"
                                               "q2_pivot.index = ['Ethmoid Culture (Deep to Ethmoid Bulla)', 'Ethmoid Tissue (Deep to Ethmoid Bulla)', 'Head of Inferior Turbinate Tissue', 'Maxillary "
                                               "Sinus', 'Maxillary Sinus Tissue', 'Middle Meatus', 'Nasal Vestibule', 'Sphenoethmoidal Recess Tissue', 'Sphenoid', 'Sphenoid Tissue', 'Superior "
                                               "Meatus', 'Uncinate Process Tissue']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q2_pivot.columns = {list(q2_pivot.columns)}')\nq2_pivot.columns = ['Actinobacteria', 'Firmicutes']\n", 'hidden': False, 'locked': False},
                                   {   'code': '>>> print("q2_pivot[\'Actinobacteria\'].sum() ==", q2_pivot[\'Actinobacteria\'].sum())\nq2_pivot[\'Actinobacteria\'].sum() == 21.0\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print("q2_pivot[\'Firmicutes\'].sum() ==", q2_pivot[\'Firmicutes\'].sum())\nq2_pivot[\'Firmicutes\'].sum() == 87.0\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q2_firmi_regions is a `DataFrame`: {isinstance(q2_firmi_regions, pd.DataFrame)}')\nq2_firmi_regions is a `DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q2_firmi_regions.columns = {list(q2_pivot.columns)}')\nq2_firmi_regions.columns = ['Actinobacteria', 'Firmicutes']\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
