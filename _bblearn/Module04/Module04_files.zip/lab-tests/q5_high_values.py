OK_FORMAT = True

test = {   'name': 'q5_high_values',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> print("swabbable_data[\'is_high\'] is a boolean column:", swabbable_data[\'is_high\'].dtype == bool)\n'
                                               "swabbable_data['is_high'] is a boolean column: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print("swabbable_data[\'is_high\'].sum() ==", swabbable_data[\'is_high\'].sum())\nswabbable_data[\'is_high\'].sum() == 27\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
