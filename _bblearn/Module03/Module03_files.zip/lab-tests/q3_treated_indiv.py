OK_FORMAT = True

test = {   'name': 'q3_treated_indiv',
    'points': 3,
    'suites': [   {   'cases': [   {'code': ">>> print('treated_df is a `DataFrame`:', isinstance(treated_df, pd.DataFrame))\ntreated_df is a `DataFrame`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('treated_df rows:', len(treated_df.index))\ntreated_df rows: 12\n", 'hidden': False, 'locked': False},
                                   {'code': '>>> print(\'treated_df["age"].sum() =\', treated_df["age"].sum())\ntreated_df["age"].sum() = 568\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
