OK_FORMAT = True

test = {   'name': 'q6_length_comparison',
    'points': 8,
    'suites': [   {   'cases': [   {'code': ">>> print('short_mean is a `float`:', isinstance(short_mean, (np.float64, float)))\nshort_mean is a `float`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('short_min is a `float` or `int`:', isinstance(short_min, (np.float64, float, int, np.int64)))\nshort_min is a `float` or `int`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('long_mean is a `float`:', isinstance(low_mean, (np.float64, float)))\nlong_mean is a `float`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('long_min is a `float` or `int`:', isinstance(low_min, (np.float64, float, int, np.int64)))\nlong_min is a `float` or `int`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> names = ['short_mean', 'short_min', 'long_mean', 'long_min']\n"
                                               '>>> vals = [short_mean, short_min, long_mean, long_min]\n'
                                               '>>> rng = (0, 10)\n'
                                               '>>> reasonable = lambda v: (v >= rng[0]) & (v <= rng[1])\n'
                                               '>>> for (name, val) in zip(names, vals):\n'
                                               "...     print(f'{name} in reasonable range of [0, 10]: {reasonable(val)}')\n"
                                               'short_mean in reasonable range of [0, 10]: True\n'
                                               'short_min in reasonable range of [0, 10]: True\n'
                                               'long_mean in reasonable range of [0, 10]: True\n'
                                               'long_min in reasonable range of [0, 10]: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
