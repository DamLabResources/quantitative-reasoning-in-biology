OK_FORMAT = True

test = {   'name': 'q1_table_loading',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print(f'trial_df is a `DataFrame`: {isinstance(trial_df, pd.DataFrame)}')\ntrial_df is a `DataFrame`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'len(trial_df.index) = {len(trial_df.index)}')\nlen(trial_df.index) = 30\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
