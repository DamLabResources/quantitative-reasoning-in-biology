OK_FORMAT = True

test = {   'name': 'q2_infection_time',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': ">>> print('infection_time column present:', 'infection_time' in trial_df.columns)\ninfection_time column present: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('negative infection times:', (trial_df['infection_time'] < 0).sum())\nnegative infection times: 0\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('infection time sum:', trial_df['infection_time'].sum())\ninfection time sum: 473\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
