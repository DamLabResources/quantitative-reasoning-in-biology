OK_FORMAT = True

test = {   'name': 'q5_vl_comparison',
    'points': 6,
    'suites': [   {   'cases': [   {'code': ">>> print('high_mean is a `float`:', isinstance(high_mean, (np.float64, float)))\nhigh_mean is a `float`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('high_min is a `float` or `int`:', isinstance(high_min, (np.float64, float, int, np.int64)))\nhigh_min is a `float` or `int`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('low_mean is a `float`:', isinstance(low_mean, (np.float64, float)))\nlow_mean is a `float`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('low_min is a `float` or `int`:', isinstance(low_min, (np.float64, float, int, np.int64)))\nlow_min is a `float` or `int`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> names = ['high_mean', 'high_min', 'low_mean', 'low_min']\n"
                                               '>>> vals = [high_mean, high_min, low_mean, low_min]\n'
                                               '>>> rng = (0, 10)\n'
                                               '>>> reasonable = lambda v: (v>=rng[0]) & (v<=rng[1])\n'
                                               '>>> for name, val in zip(names, vals):\n'
                                               "...     print(f'{name} in reasonable range of [0, 10]: {reasonable(val)}')\n"
                                               'high_mean in reasonable range of [0, 10]: True\n'
                                               'high_min in reasonable range of [0, 10]: True\n'
                                               'low_mean in reasonable range of [0, 10]: True\n'
                                               'low_min in reasonable range of [0, 10]: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
