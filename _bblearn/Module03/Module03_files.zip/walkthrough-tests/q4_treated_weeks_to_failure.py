OK_FORMAT = True

test = {   'name': 'q4_treated_weeks_to_failure',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print('treated_average_weeks is a `float`:', isinstance(treated_average_weeks, float))\ntreated_average_weeks is a `float`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'treated_average_weeks = {treated_average_weeks:0.1f}')\ntreated_average_weeks = 6.9\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
