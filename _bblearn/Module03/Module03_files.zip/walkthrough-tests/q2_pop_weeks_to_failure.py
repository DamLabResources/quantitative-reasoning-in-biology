OK_FORMAT = True

test = {   'name': 'q2_pop_weeks_to_failure',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> print(f'average_weeks = {average_weeks:0.1f}')\naverage_weeks = 4.9\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
