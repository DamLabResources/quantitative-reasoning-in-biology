OK_FORMAT = True

test = {   'name': 'q3_treated_weeks_to_failure_indexing',
    'points': 2,
    'suites': [   {   'cases': [{'code': ">>> print(f'treated_average_weeks = {treated_average_weeks:0.1f}')\ntreated_average_weeks = 6.9\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
