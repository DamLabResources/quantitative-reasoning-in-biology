OK_FORMAT = True

test = {   'name': 'q4_untreated_weeks_to_failure',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print('untreated_average_weeks is a `float`:', isinstance(untreated_average_weeks, float))\nuntreated_average_weeks is a `float`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'untreated_average_weeks = {untreated_average_weeks:0.1f}')\nuntreated_average_weeks = 3.6\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
