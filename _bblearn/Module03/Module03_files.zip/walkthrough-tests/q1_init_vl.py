OK_FORMAT = True

test = {   'name': 'q1_init_vl',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print('init_vl is a `pd.Series`:', isinstance(init_vl, pd.Series))\ninit_vl is a `pd.Series`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'init_vl_sum = {init_vl.sum()}')\ninit_vl_sum = 1628\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
