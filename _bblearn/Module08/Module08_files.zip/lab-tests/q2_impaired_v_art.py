OK_FORMAT = True

test = {   'name': 'q2_impaired_v_art',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q2_plot a figure or axis:', isinstance(q2_plot, (plt.Axes, plt.Figure)))\nIs q2_plot a figure or axis: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('Is q2_linkage a yes or no?', q2_linkage.lower() in {'yes', 'no'})\nIs q2_linkage a yes or no? True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('Is q2_therapy Stavudine or Truvada?', q2_therapy in {'Stavudine', 'Truvada'})\nIs q2_therapy Stavudine or Truvada? True\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
