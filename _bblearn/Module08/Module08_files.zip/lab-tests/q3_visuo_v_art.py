OK_FORMAT = True

test = {   'name': 'q3_visuo_v_art',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print('Is q3_is_normal a yes or no?', q3_is_normal.lower() in {'yes', 'no'})\nIs q3_is_normal a yes or no? True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('Is q3_plot a figure or axis:', isinstance(q3_plot, (plt.Axes, plt.Figure)))\nIs q3_plot a figure or axis: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('Is q3_sig_diff a yes or no?', q3_sig_diff.lower() in {'yes', 'no'})\nIs q3_sig_diff a yes or no? True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
