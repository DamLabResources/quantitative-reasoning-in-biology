OK_FORMAT = True

test = {   'name': 'q1_impaired_bar',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q1_plot a figure or axis:', isinstance(q1_plot, (plt.Axes, plt.Figure)))\nIs q1_plot a figure or axis: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is q1_most_impaired is a column name:', q1_most_impaired in data.columns)\nIs q1_most_impaired is a column name: True\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
