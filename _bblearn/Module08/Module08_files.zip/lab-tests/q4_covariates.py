OK_FORMAT = True

test = {   'name': 'q4_covariates',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q4_plot a figure or axis:', isinstance(q4_plot, (plt.Axes, plt.Figure)))\nIs q4_plot a figure or axis: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('Is q4_is_sig a yes or no?', q4_is_sig.lower() in {'yes', 'no'})\nIs q4_is_sig a yes or no? True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
