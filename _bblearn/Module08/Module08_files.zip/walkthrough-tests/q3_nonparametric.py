OK_FORMAT = True

test = {   'name': 'q3_nonparametric',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q3_stats is a `DataFrame`: {isinstance(q3_stats, pd.DataFrame)}')\nq3_stats is a `DataFrame`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print(f'q3_post_hoc is a `DataFrame`: {isinstance(q3_post_hoc, pd.DataFrame)}')\nq3_post_hoc is a `DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q3_post_hoc is a `str`: {isinstance(q3_comparison, str)}')\nq3_post_hoc is a `str`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': '>>> print(f"""q3_stats.loc["Kruskal", "H"] = {q3_stats.loc[\'Kruskal\', \'H\']:0.3f}""")\nq3_stats.loc["Kruskal", "H"] = 22.498\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(f"""q3_post_hoc["Parametric"].any() = {q3_post_hoc[\'Parametric\'].any()}""")\nq3_post_hoc["Parametric"].any() = False\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
