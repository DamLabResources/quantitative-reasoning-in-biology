OK_FORMAT = True

test = {   'name': 'q1_demographic_breakdown',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q1_race_counts is a `Series`: {isinstance(q1_race_counts, pd.Series)}')\nq1_race_counts is a `Series`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q1_sex_counts is a `Series`: {isinstance(q1_sex_counts, pd.Series)}')\nq1_sex_counts is a `Series`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': '>>> print(f"q1_race_counts: {q1_race_counts[[\'AA\', \'C\', \'H\']]}")\n'
                                               'q1_race_counts: race\n'
                                               'AA    220\n'
                                               'C      74\n'
                                               'H      31\n'
                                               'Name: count, dtype: int64\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(f"q1_sex_counts: {q1_sex_counts[[\'male\', \'female\']]}")\nq1_sex_counts: sex\nmale      225\nfemale    100\nName: count, dtype: int64\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
