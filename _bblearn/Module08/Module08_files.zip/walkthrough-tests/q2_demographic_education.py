OK_FORMAT = True

test = {   'name': 'q2_demographic_education',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q2_pval_ans is a `str`: {isinstance(q2_pval_ans, str)}')\nq2_pval_ans is a `str`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2_pval_ans =', q2_pval_ans)\nq2_pval_ans = yes\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2_inter_ans is a `str`: {isinstance(q2_inter_ans, str)}')\nq2_inter_ans is a `str`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2_inter_ans =', q2_inter_ans)\nq2_inter_ans = less\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
