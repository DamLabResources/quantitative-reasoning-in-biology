OK_FORMAT = True

test = {   'name': 'q5_multiple_choices',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q5_high_noise_effect_size = {q5_high_noise_effect_size:0.3}')\nq5_high_noise_effect_size = 0.774\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q5_new_assay_effect_size = {q5_new_assay_effect_size:0.3}')\nq5_new_assay_effect_size = 1.55\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
