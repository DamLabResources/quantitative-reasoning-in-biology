OK_FORMAT = True

test = {   'name': 'q4_min_effect',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q4_effect_size = {q4_effect_size:0.3}')\nq4_effect_size = 0.963\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q4_min_change = {q4_min_change:0.3}')\nq4_min_change = 3.37\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
