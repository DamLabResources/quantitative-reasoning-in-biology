OK_FORMAT = True

test = {   'name': 'q6',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print('q6a is a str:', isinstance(q6a, str))\nq6a is a str: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('q6b is a str:', isinstance(q6b, str))\nq6b is a str: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('q6c is a number:', isinstance(q6c, (int, float)))\nq6c is a number: True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
