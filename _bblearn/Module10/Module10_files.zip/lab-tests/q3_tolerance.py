OK_FORMAT = True

test = {   'name': 'q3_tolerance',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'power = {power:0.2}')\npower = 0.8\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'alpha = {alpha:0.2}')\nalpha = 0.01\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
