OK_FORMAT = True

test = {   'name': 'q2_effect_size',
    'points': 5,
    'suites': [   {   'cases': [{'code': ">>> print(f'q2_effect_size = {q2_effect_size:0.3}')\nq2_effect_size = 1.16\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
