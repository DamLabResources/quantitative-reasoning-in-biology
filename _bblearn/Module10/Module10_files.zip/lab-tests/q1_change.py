OK_FORMAT = True

test = {   'name': 'q1_change',
    'points': 5,
    'suites': [   {   'cases': [{'code': ">>> print(f'q1_change = {q1_change:0.3}')\nq1_change = 4.07\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
