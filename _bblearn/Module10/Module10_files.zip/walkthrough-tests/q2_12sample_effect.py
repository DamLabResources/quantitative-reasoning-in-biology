OK_FORMAT = True

test = {   'name': 'q2_12sample_effect',
    'points': 5,
    'suites': [   {   'cases': [{'code': ">>> print(f'q2_effect = {q2_effect:0.3}')\nq2_effect = 0.766\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
