OK_FORMAT = True

test = {   'name': 'q1_twosample_power',
    'points': 5,
    'suites': [{'cases': [{'code': ">>> print(f'q1_power = {q1_power:0.3}')\nq1_power = 0.302\n", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
