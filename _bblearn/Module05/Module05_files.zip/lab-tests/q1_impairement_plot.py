OK_FORMAT = True

test = {   'name': 'q1_impairement_plot',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print('Is q1_ax an axis handle:', isinstance(q1_ax, plt.Axes))\nIs q1_ax an axis handle: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('q1_ax x-label:', q1_ax.get_xlabel())\nq1_ax x-label: Impairment Level\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('q1_ax x-ticklabels:', [x.get_text() for x in q1_ax.get_xticklabels()])\nq1_ax x-ticklabels: ['none', 'mild', 'impaired']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('q1_ax y-label:', q1_ax.get_ylabel())\nq1_ax y-label: Participants\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('q1_ax ylim:', q1_ax.get_ylim())\nq1_ax ylim: (0.0, 150.0)\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
