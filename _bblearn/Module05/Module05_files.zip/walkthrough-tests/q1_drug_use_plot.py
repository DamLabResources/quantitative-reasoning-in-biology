OK_FORMAT = True

test = {   'name': 'q1_drug_use_plot',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> expected_index = pd.Index(['cocaine_use', 'cannabinoid_use', 'multi_use', 'non_use'])\n"
                                               '>>> missing_index = expected_index.difference(data.columns)\n'
                                               ">>> print(f'Missing: {list(missing_index)}' if len(missing_index) else 'All expected columns in data')\n"
                                               'All expected columns in data\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Checking sums of derived columns\\n', 'MU:', data['multi_use'].sum(), 'NU:', data['non_use'].sum())\n"
                                               'Checking sums of derived columns\n'
                                               ' MU: 84 NU: 76\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Checking use_counts\\n', use_counts['cocaine_use'], use_counts['cannabinoid_use'], use_counts['multi_use'], use_counts['non_use'])\n"
                                               'Checking use_counts\n'
                                               ' 115 117 84 76\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
