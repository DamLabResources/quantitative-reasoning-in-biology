OK_FORMAT = True

test = {   'name': 'q2_neuro_use_plot',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print('Expected plots of: ', sorted(q2_axes.index))\nExpected plots of:  ['ifnalpha', 'vegf']\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('Expected ticks of: ', [t.get_text() for t in q2_axes['ifnalpha'].get_xticklabels()])\nExpected ticks of:  ['impaired', 'mild', 'none']\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
