OK_FORMAT = True

test = {   'name': 'q1_molarity',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print('Is dna_molarity a float:', isinstance(dna_molarity, float))\nIs dna_molarity a float: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'dna_molarity = {dna_molarity:0.1f}')\ndna_molarity = 278.0\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
