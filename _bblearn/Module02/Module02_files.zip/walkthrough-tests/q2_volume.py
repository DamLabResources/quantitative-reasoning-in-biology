OK_FORMAT = True

test = {   'name': 'q2_volume',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print('Is volume_to_add a float:', isinstance(volume_to_add, float))\nIs volume_to_add a float: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'volume_to_add = {volume_to_add:0.2f}')\nvolume_to_add = 0.72\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
