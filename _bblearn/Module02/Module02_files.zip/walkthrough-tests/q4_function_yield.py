OK_FORMAT = True

test = {   'name': 'q4_function_yield',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'Testing calc_yield(50.6, 280, 25) = {calc_yield(50.6, 280, 25):0.1f}')\nTesting calc_yield(50.6, 280, 25) = 6950.5\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'Testing calc_yield(35, 263, 20, base_weight=320) = {calc_yield(35, 77, 19, base_weight=320):0.1f}')\n"
                                               'Testing calc_yield(35, 263, 20, base_weight=320) = 26988.6\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
