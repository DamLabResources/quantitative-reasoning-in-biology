OK_FORMAT = True

test = {   'name': 'q3_dna_yield',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is dna_yield_description a str:', isinstance(dna_yield_description, str))\nIs dna_yield_description a str: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is the correct number in the description:', '6951' in dna_yield_description)\nIs the correct number in the description: True\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
