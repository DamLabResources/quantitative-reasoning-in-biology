OK_FORMAT = True

test = {   'name': 'q3_molarity',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is paragon_fresh_molarity a float:', isinstance(paragon_fresh_molarity, float))\nIs paragon_fresh_molarity a float: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is paragon_degraded_molarity a float:', isinstance(paragon_degraded_molarity, float))\nIs paragon_degraded_molarity a float: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is paragon_fresh_molarity reasonable [50, 500]:',\n"
                                               '...       (paragon_fresh_molarity > 50) & (paragon_fresh_molarity < 500))\n'
                                               'Is paragon_fresh_molarity reasonable [50, 500]: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is paragon_degraded_molarity reasonable [50, 500]:',\n"
                                               '...       (paragon_degraded_molarity > 50) & (paragon_degraded_molarity < 500))\n'
                                               'Is paragon_degraded_molarity reasonable [50, 500]: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
