OK_FORMAT = True

test = {   'name': 'q2_mol_weight',
    'points': 4,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is paragon_template_weight an int or float:', isinstance(paragon_template_weight, (float, int)))\n"
                                               'Is paragon_template_weight an int or float: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is pacbio_template_weight an int or float:', isinstance(pacbio_template_weight, (float, int)))\n"
                                               'Is pacbio_template_weight an int or float: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'paragon_template_weight = {paragon_template_weight:0.1f}')\nparagon_template_weight = 185250.0\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'paragon_template_weight = {paragon_template_weight:0.1f}')\nparagon_template_weight = 185250.0\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
