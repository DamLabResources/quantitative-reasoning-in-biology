OK_FORMAT = True

test = {   'name': 'q1_amp_length',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print(f'paragon_amplicon_length = {paragon_amplicon_length}')\nparagon_amplicon_length = 285\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'pacbio_amplicon_length = {pacbio_amplicon_length}')\npacbio_amplicon_length = 2200\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
