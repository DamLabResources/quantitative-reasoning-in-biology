OK_FORMAT = True

test = {   'name': 'q4_dna_yield',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is pacbio_fresh_yield a float:', isinstance(pacbio_fresh_yield, float))\nIs pacbio_fresh_yield a float: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is pacbio_degraded_yield a float:', isinstance(pacbio_degraded_yield, float))\nIs pacbio_degraded_yield a float: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is pacbio_fresh_yield reasonable [50, 500]:',\n"
                                               '...       (pacbio_fresh_yield > 50) & (pacbio_fresh_yield < 500))\n'
                                               'Is pacbio_fresh_yield reasonable [50, 500]: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is pacbio_degraded_yield reasonable [50, 500]:',\n"
                                               '...       (pacbio_degraded_yield > 50) & (pacbio_degraded_yield < 500))\n'
                                               'Is pacbio_degraded_yield reasonable [50, 500]: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'pacbio_fresh_molarity = {pacbio_fresh_molarity:0.1f}')\npacbio_fresh_molarity = 26.6\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'pacbio_degraded_molarity = {pacbio_degraded_molarity:0.1f}')\npacbio_degraded_molarity = 5.2\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'pacbio_fresh_yield = {pacbio_fresh_yield:0.1f}')\npacbio_fresh_yield = 399.7\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'pacbio_degraded_yield = {pacbio_degraded_yield:0.1f}')\npacbio_degraded_yield = 77.6\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
