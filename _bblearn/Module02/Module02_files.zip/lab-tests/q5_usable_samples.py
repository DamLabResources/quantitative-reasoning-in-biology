OK_FORMAT = True

test = {   'name': 'q5_usable_samples',
    'points': 6,
    'suites': [   {   'cases': [   {   'code': ">>> choices = {'yes', 'no'}\n"
                                               ">>> names = ['paragon_fresh_usable', 'paragon_degraded_usable', \n"
                                               "...           'pacbio_fresh_usable', 'pacbio_degraded_usable']\n"
                                               '>>> answers = [paragon_fresh_usable, paragon_degraded_usable, \n'
                                               '...           pacbio_fresh_usable, pacbio_degraded_usable]\n'
                                               '>>> for name, ans in zip(names, answers):\n'
                                               "...     print(f'Is {name} a str:', isinstance(ans, str))\n"
                                               '...     print(f\'Is {name} "yes" or "no":\', ans in choices)\n'
                                               'Is paragon_fresh_usable a str: True\n'
                                               'Is paragon_fresh_usable "yes" or "no": True\n'
                                               'Is paragon_degraded_usable a str: True\n'
                                               'Is paragon_degraded_usable "yes" or "no": True\n'
                                               'Is pacbio_fresh_usable a str: True\n'
                                               'Is pacbio_fresh_usable "yes" or "no": True\n'
                                               'Is pacbio_degraded_usable a str: True\n'
                                               'Is pacbio_degraded_usable "yes" or "no": True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
