OK_FORMAT = True

test = {   'name': 'q5_infection_length_cocaine',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q5_plot an Axes, FactGrid, or Figure:', isinstance(q5_plot, (plt.Axes, plt.Figure, sns.FacetGrid)))\n"
                                               'Is q5_plot an Axes, FactGrid, or Figure: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'Is q5_infection_length_cocaine_slope in {"yes", "no"}:\', q5_infection_length_cocaine_slope in {"yes", "no"})\n'
                                               'Is q5_infection_length_cocaine_slope in {"yes", "no"}: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
