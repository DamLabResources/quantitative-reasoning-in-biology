OK_FORMAT = True

test = {   'name': 'q4_infection_length',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q4_plot an Axes, FactGrid, or Figure:', isinstance(q4_plot, (plt.Axes, plt.Figure, sns.FacetGrid)))\n"
                                               'Is q4_plot an Axes, FactGrid, or Figure: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'Is q4_infection_length_corr in {"yes", "no"}:\', q4_infection_length_corr in {\'yes\', \'no\'})\n'
                                               'Is q4_infection_length_corr in {"yes", "no"}: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
