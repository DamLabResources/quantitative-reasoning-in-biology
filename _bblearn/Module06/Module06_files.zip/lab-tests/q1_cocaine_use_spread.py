OK_FORMAT = True

test = {   'name': 'q1_cocaine_use_spread',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q1_plot an Axes, FactGrid, or Figure:', isinstance(q1_plot, (plt.Axes, plt.Figure, sns.FacetGrid)))\n"
                                               'Is q1_plot an Axes, FactGrid, or Figure: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'Is q1_higher_level in {"users", "non-users", "same"}:\', q1_higher_level in {"users", "non-users", "same"})\n'
                                               'Is q1_higher_level in {"users", "non-users", "same"}: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
