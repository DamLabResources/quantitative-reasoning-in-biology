OK_FORMAT = True

test = {   'name': 'q3_cocaine_use_gender_mean',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q3_plot an Axes, FactGrid, or Figure:', isinstance(q3_plot, (plt.Axes, plt.Figure, sns.FacetGrid)))\n"
                                               'Is q3_plot an Axes, FactGrid, or Figure: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'Is q3_gender_impact in {"likely", "unlikely"}:\', q3_gender_impact in {"likely", "unlikely"})\n'
                                               'Is q3_gender_impact in {"likely", "unlikely"}: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
