OK_FORMAT = True

test = {   'name': 'impact_of_sample_size',
    'points': 2,
    'suites': [   {   'cases': [{'code': '>>> print("impact_of_sample_size = \'uncertainty\'")\nimpact_of_sample_size = \'uncertainty\'\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
