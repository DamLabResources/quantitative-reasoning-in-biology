OK_FORMAT = True

test = {   'name': 'q1_cells_per_well',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is cells_per_well a pd.Series?', isinstance(cells_per_well, pd.Series))\nIs cells_per_well a pd.Series? True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'The mean number of cells per well is {cells_per_well.mean():0.2f}')\nThe mean number of cells per well is 525.97\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
