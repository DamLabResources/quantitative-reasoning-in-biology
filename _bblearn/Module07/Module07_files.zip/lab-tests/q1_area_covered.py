OK_FORMAT = True

test = {   'name': 'q1_area_covered',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q1_plot an Axes, FactGrid, or Figure:', isinstance(q1_plot, (plt.Axes, plt.Figure, sns.FacetGrid)))\n"
                                               'Is q1_plot an Axes, FactGrid, or Figure: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('`cell_level_data` has a column called `fraction_area_covered`:', 'fraction_area_covered' in cell_level_data.columns)\n"
                                               '`cell_level_data` has a column called `fraction_area_covered`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'`cell_level_data["fraction_area_covered"]` is between 0 and 1:\', cell_level_data[\'fraction_area_covered\'].min() >= 0, '
                                               "cell_level_data['fraction_area_covered'].max() <= 1)\n"
                                               '`cell_level_data["fraction_area_covered"]` is between 0 and 1: True True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
