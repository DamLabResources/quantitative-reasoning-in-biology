OK_FORMAT = True

test = {   'name': 'q3_partial_corr',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q3_plot is a `Figure` or `Axes`: {isinstance(q3_plot, (plt.Figure, plt.Axes))}')\nq3_plot is a `Figure` or `Axes`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q3_corr_res is a `DataFrame`: {isinstance(q3_corr_res, pd.DataFrame)}')\nq3_corr_res is a `DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q3_corr_sig is str and {"yes", "no"}`:\', isinstance(q3_corr_sig, str) and q3_corr_sig in {\'yes\', \'no\'})\n'
                                               'q3_corr_sig is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q3_corr_r is a `float`: {isinstance(q3_corr_r, float)}')\nq3_corr_r is a `float`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print(f'q3_partial_corr_r is a `float`: {isinstance(q3_partial_corr_r, float)}')\nq3_partial_corr_r is a `float`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q3_same_res is str and {"yes", "no"}`:\', isinstance(q3_same_res, str) and q3_same_res in {\'yes\', \'no\'})\n'
                                               'q3_same_res is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
