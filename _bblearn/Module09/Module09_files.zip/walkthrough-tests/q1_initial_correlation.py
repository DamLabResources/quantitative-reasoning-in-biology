OK_FORMAT = True

test = {   'name': 'q1_initial_correlation',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q1_most_correlated is a `str`: {isinstance(q1_most_correlated, str)}')\nq1_most_correlated is a `str`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> valid_continious = {'age', 'education', 'YearsSeropositive'}\n"
                                               ">>> print(f'q1_most_correlated is a valid answer: {q1_most_correlated in valid_continious}')\n"
                                               'q1_most_correlated is a valid answer: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> print(f\'q1_most_correlated = "{q1_most_correlated}"\')\nq1_most_correlated = "YearsSeropositive"\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
