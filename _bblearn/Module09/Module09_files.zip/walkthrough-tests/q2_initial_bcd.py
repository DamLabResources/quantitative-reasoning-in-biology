OK_FORMAT = True

test = {   'name': 'q2_initial_bcd',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q2_most_bcd is a `str`: {isinstance(q2_most_bcd, str)}')\nq2_most_bcd is a `str`: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> valid_discete = {'race', 'sex', 'ART'}\n"
                                               ">>> print(f'q2_most_bcd is a valid answer: {q2_most_bcd in valid_discete}')\n"
                                               'q2_most_bcd is a valid answer: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> print(f\'q2_most_bcd = "{q2_most_bcd}"\')\nq2_most_bcd = "race"\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
