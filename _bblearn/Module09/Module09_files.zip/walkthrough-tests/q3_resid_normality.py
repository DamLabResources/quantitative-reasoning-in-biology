OK_FORMAT = True

test = {   'name': 'q3_resid_normality',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q3_plot is a `Figure` or `Axes`: {isinstance(q3_plot, (plt.Figure, plt.Axes))}')\nq3_plot is a `Figure` or `Axes`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q3_norm_res is a `pd.DataFrame`: {isinstance(q3_norm_res, pd.DataFrame)}')\nq3_norm_res is a `pd.DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(f\'q3_norm_res.loc[0, "pval"] =\', q3_norm_res.loc[0, \'pval\'].round(3))\nq3_norm_res.loc[0, "pval"] = 0.392\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q3_is_norm is str`: {isinstance(q3_is_norm, str)}')\nq3_is_norm is str`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q3_is_norm = ', q3_is_norm)\nq3_is_norm =  yes\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
