OK_FORMAT = True

test = {   'name': 'q4_art_test',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q4_plot is a `Figure` or `Axes`: {isinstance(q4_plot, (plt.Figure, plt.Axes))}')\nq4_plot is a `Figure` or `Axes`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q4_res is a `pd.DataFrame`: {isinstance(q4_res, pd.DataFrame)}')\nq4_res is a `pd.DataFrame`: True\n", 'hidden': False, 'locked': False},
                                   {'code': '>>> print(f\'q4_res.loc[0, "p-unc"] =\', q4_res.loc[0, "p-unc"].round(4))\nq4_res.loc[0, "p-unc"] = 0.0055\n', 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q4_art_impact is str`: {isinstance(q4_art_impact, str)}')\nq4_art_impact is str`: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q4_art_impact = ', q4_art_impact)\nq4_art_impact =  yes\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
