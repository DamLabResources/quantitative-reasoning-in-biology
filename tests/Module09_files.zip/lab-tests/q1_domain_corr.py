OK_FORMAT = True

test = {   'name': 'q1_domain_corr',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q1_plot is a `Figure` or `Axes`: {isinstance(q1_plot, (plt.Figure, plt.Axes))}')\nq1_plot is a `Figure` or `Axes`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print(f'q1_corr_res is a `pd.DataFrame`: {isinstance(q1_corr_res, pd.DataFrame)}')\nq1_corr_res is a `pd.DataFrame`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q1_is_corr is str`: {isinstance(q1_is_corr, str)}')\nq1_is_corr is str`: True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
