OK_FORMAT = True

test = {   'name': 'q2_exec_adj',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': '>>> print(\'q2_model_resid_normal is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q2_model_resid_normal, str) and q2_model_resid_normal in {'yes', 'no'})\n"
                                               'q2_model_resid_normal is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q2_processing_age is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q2_processing_age, str) and q2_processing_age in {'yes', 'no'})\n"
                                               'q2_processing_age is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q2_processing_race is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q2_processing_race, str) and q2_processing_race in {'yes', 'no'})\n"
                                               'q2_processing_race is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q2_processing_sex is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q2_processing_sex, str) and q2_processing_sex in {'yes', 'no'})\n"
                                               'q2_processing_sex is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q2_processing_edu is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q2_processing_edu, str) and q2_processing_edu in {'yes', 'no'})\n"
                                               'q2_processing_edu is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q2_processing_ys is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q2_processing_ys, str) and q2_processing_ys in {'yes', 'no'})\n"
                                               'q2_processing_ys is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q2_processing_art is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q2_processing_art, str) and q2_processing_art in {'yes', 'no'})\n"
                                               'q2_processing_art is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
