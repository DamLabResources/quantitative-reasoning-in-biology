OK_FORMAT = True

test = {   'name': 'q4_full_corr',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': ">>> print(f'q4_plot is a `Figure` or `Axes`: {isinstance(q4_plot, (plt.Figure, plt.Axes))}')\nq4_plot is a `Figure` or `Axes`: True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> print(\'q4_sig_cor is str and {"yes", "no"}`:\',\n'
                                               "...       isinstance(q4_sig_cor, str) and q4_sig_cor in {'yes', 'no'})\n"
                                               'q4_sig_cor is str and {"yes", "no"}`: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
