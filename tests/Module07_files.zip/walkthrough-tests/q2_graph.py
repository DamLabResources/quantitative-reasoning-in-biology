OK_FORMAT = True

test = {   'name': 'q2_graph',
    'points': 5,
    'suites': [   {   'cases': [   {'code': ">>> print(f'q2a = {q2a}')\nq2a = 5.0\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2b = {q2b}')\nq2b = no\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
