OK_FORMAT = True

test = {   'name': 'q2_merge',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': ">>> print('Is q2_plot an Axes, FactGrid, or Figure:', isinstance(q2_plot, (plt.Axes, plt.Figure, sns.FacetGrid)))\n"
                                               'Is q2_plot an Axes, FactGrid, or Figure: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q2a = {q2a}')\nq2a = 5.0\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print(f'q2b = {q2b}')\nq2b = no\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
