OK_FORMAT = True

test = {   'name': 'q1_impairement_plot',
    'points': 2,
    'suites': [   {   'cases': [   {'code': ">>> print('Is q1_largest a string:', isinstance(q1_largest, str))\nIs q1_largest a string: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('q1_largest is one of the impairment levels:', q1_largest.lower() in {'none', 'mild', 'impaired'})\n"
                                               'q1_largest is one of the impairment levels: True\n',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('Is q1_smallest a string:', isinstance(q1_smallest, str))\nIs q1_smallest a string: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('q1_smallest is one of the impairment levels:', q1_smallest.lower() in {'none', 'mild', 'impaired'})\n"
                                               'q1_smallest is one of the impairment levels: True\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
