OK_FORMAT = True

test = {   'name': 'q2_pro_inflam',
    'points': 10,
    'suites': [   {   'cases': [   {   'code': ">>> print('What is the q2_cytokine_summary index:', sorted(q2_cytokine_summary.index))\n"
                                               "What is the q2_cytokine_summary index: ['impaired', 'mild', 'none']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('What is the q2_cytokine_summary columns:', sorted(q2_cytokine_summary.columns))\n"
                                               "What is the q2_cytokine_summary columns: ['il6', 'mcp1', 'mip1alpha', 'tnfalpha']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print('Is q2_ans a string:', isinstance(q2_ans, str))\nIs q2_ans a string: True\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('Is q2_ans a cytokine:', q2_ans in data.columns)\nIs q2_ans a cytokine: True\n", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
