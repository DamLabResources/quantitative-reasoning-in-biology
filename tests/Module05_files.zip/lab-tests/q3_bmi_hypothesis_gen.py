OK_FORMAT = True

test = {   'name': 'q3_bmi_hypothesis_gen',
    'points': 10,
    'suites': [   {   'cases': [   {'code': ">>> print('Is q3_cross_cor a DataFrame:', isinstance(q3_cross_cor, pd.DataFrame))\nIs q3_cross_cor a DataFrame: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('Is q3_cross_cor.index:', sorted(q3_cross_cor.index))\n"
                                               "Is q3_cross_cor.index: ['bmi', 'egf', 'eotaxin', 'fgfbasic', 'gcsf', 'gmcsf', 'hgf', 'ifnalpha', 'ifngamma', 'il10', 'il12', 'il13', 'il15', 'il17', "
                                               "'il1beta', 'il2', 'il2r', 'il4', 'il5', 'il6', 'il7', 'il8', 'ilra', 'ip10', 'mcp1', 'mig', 'mip1alpha', 'mip1beta', 'tnfalpha', 'vegf']\n",
                                       'hidden': False,
                                       'locked': False},
                                   {'code': ">>> print(f'q3_cross_cor.sum().sum() = {q3_cross_cor.sum().sum():0.2f}')\nq3_cross_cor.sum().sum() = 301.59\n", 'hidden': False, 'locked': False},
                                   {'code': ">>> print('Is q3_top5 a Series:', isinstance(q3_top5, pd.Series))\nIs q3_top5 a Series: True\n", 'hidden': False, 'locked': False},
                                   {   'code': ">>> print('Are all q3_top5 cytokines?', len(q3_top5.index.difference(data.columns[3:-5])) == 0)\nAre all q3_top5 cytokines? True\n",
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': ">>> print('Is BMI in the top cytokine list:', 'yes' if 'bmi' in q3_top5.index else 'no')\nIs BMI in the top cytokine list: no\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
